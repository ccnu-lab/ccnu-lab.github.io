module.exports = {
  printWidth: 100,
  tabWidth: 2,
  useTabs: false,
  semi: true,
  singleQuote: true,
  trailingComma: 'es5',
  jsxBracketSameLine: false,
  arrowParens: 'always',
  bracketSpacing: false,
};
