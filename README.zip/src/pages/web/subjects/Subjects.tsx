import React from 'react';

export default function Subjects() {
  return <a>课题设置</a>;
}
