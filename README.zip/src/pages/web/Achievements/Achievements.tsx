import React from 'react';

export default function Achievements() {
  return <a>成果展示</a>;
}
