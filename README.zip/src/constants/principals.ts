import principal_default from '@/assets/images/principal_default.png';
const principals = [
  {image: principal_default, name: '张三'},
  {image: principal_default, name: '张三'},
  {image: principal_default, name: '张三'},
  {image: principal_default, name: '张三'},
  {image: principal_default, name: '张三'},
];
export default principals;
