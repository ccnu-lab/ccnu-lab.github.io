const dynamics = [
  {
    id: new Date().getTime().toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 90000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 80000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 70000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 60000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 50000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 40000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 30000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 20000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 10000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
  {
    id: (new Date().getTime() - 9000).toString(),
    title: '科技创新2030—“新一代人工智能”重大项目“连续学习理论和方法”2022年度进展总结会成功召开',
    createTime: new Date(),
  },
];
export default dynamics;
